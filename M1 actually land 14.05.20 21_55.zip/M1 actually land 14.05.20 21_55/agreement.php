<html>
<head>
              <title> Terms of Service </title>
              <meta charset = "UTF-8" />
</head>
<body>
<div style = "padding: 20px; font-size: 14px; font-family: 'PT Sans';">
              <h1 style = "font-family: 'PT Sans'; padding: 0; margin: 0; margin-bottom: 16px; font-size: 19pt; font-weight: bold;"> User agreement </h1>
 
              <p> This user agreement is concluded between you - the Client, the Advertiser, the Site Administrator and the CPA network.
              </p>
              <p> <strong> Customer </strong> - a person who is attracted by promotion methods to purchase / alienate offers for goods and / or services offered by the Advertiser, intending to order or purchase or ordering, purchasing or using goods exclusively for personal, family , domestic and other needs not related to business activities.
              </p>
              <p> <strong> Advertiser </strong> - a person who wants to place an offer on a CPA network in order to alienate a particular product and / or service.
              </p>
              <p> <strong> CPA network </strong> (short for Cost Per Action, i.e. payment for action) is an electronic business environment in which a contractual relationship develops between the Advertiser and the CPA network, by virtue of which, the Advertiser it offers offers for goods and / or services, and the CPA network, in turn, provides the opportunity to place offers on its Internet space to search for people promoting the advertiser’s goods / services on the Internet.
              </p>
              <p> <strong> Site Administrator </strong> - a person specified as the site administrator when registering a domain name, providing the Advertiser with the opportunity to post information on the site.
              </p>
              <p> <strong> Parties </strong> - Client, Advertiser, CPA network, Site Administrator.
              </p>
              <p> <strong> Website </strong> is an online resource of an online store, which is under organizational management and belongs to the Advertiser, under the terms of a private property right.
              </p>
              <p> <strong> Public offer </strong> - an offer addressed by the administration to an indefinite number of persons or several specific persons, which definitely, specifically expresses the intention of the person making the offer to consider himself having concluded this user agreement with the addressee who will accept the offer.
              </p>
              <p> <strong> Acceptance </strong> - full acceptance by one of the Parties of the terms of the public offer of the CPA network for the conclusion of this user agreement. The acceptance of a public offer occurs at the time of the start of using the Site (including for informational purposes) and its services (services).
              </p>
              <p> <strong> 1. General Terms </strong>
              </p>
              <p> 1.1. This User Agreement (hereinafter referred to as the “Agreement”) defines the general rules for visiting, using the services and general behaviors on the Site by the Client and regulates civil law relations that develop between the Client and the Advertiser, as well as the Client, Advertiser and the CPA network the process of their interaction.
              </p>
              <p> 1.2. This Agreement may be amended unilaterally by decision of the CPA network and / or Advertiser. The CPA network and / or the Advertiser is not obligated to personally notify the Client of such changes. The new version of the Agreement comes into force from the moment of purchasing the goods / services of the Advertiser by the Client.
              </p>
              <p> 1.3. The terms of the Agreement apply to all Customers of the site, without exception.
              </p>
              <p> 1.4. The Client, starting to use the Site, confirms the fact that he has read the provisions of this Agreement in his right mind and with a clear memory, understands them fully and accepts the conditions for using the Site in full. In case of disagreement with the provisions of this Agreement (partially or as a whole), a person who has expressed such a will does not have the right to use the information field of the Site.
              </p>
              <p> <strong> 2. Regulation of the interaction of the parties </strong>
              </p>
              <p> 2.1. The implementation of the services and / or opportunities provided by the Site does not provide the Client with any exclusive rights and privileges.
              </p>
              <p> 2.2. The parties to this Agreement have agreed that the CPA network has the right to place advertising blocks, banners, ads on the Site in any of its areas, including where information published by the Client is posted, without the additional consent of the Client.
              </p>
              <p> 2.3. The information posted on the Site by the CPA network, with the exception of information posted on behalf of, or personally by the Advertiser, is the result of the intellectual activity of the CPA network and all property and personal non-property rights to such information belong to the CPA network until it otherwise established. At the same time, the Client does not have any exclusive rights to the result of the intellectual activity of the CPA network, expressed in graphic, text, audio-video form posted by the CPA network on the Site.
              </p>
              <p> 2.4. The CPA network is not liable for the protection of the violated rights of the Client in the context of the settlement of disputes arising on this basis, including in court.
              </p>
              <p> 2.5. CPA-network is not the owner / manufacturer of goods and / or services posted on the Site and is not responsible for violation of the rights of the Client. The purpose of the CPA network under this Agreement is to collect statistical information on the number of potential customers interested in acquiring goods and / or services permitted by the Advertiser methods.
              </p>
              <p> 2.6. Violation by the Client or the Advertiser of copyright belonging to the CPA network and (or) other persons entails liability for the violator, provided for by the provisions of the current legislation of the Russian Federation.
              </p>
              <p> 2.7. In case of violation of copyright by the Client, through the illegal placement of materials not belonging to the Client, the CPA network removes such materials from free access, at the first request of the legal copyright holder.
              </p>
              <p> 2.8. The Client is prohibited from posting information on the Site that directly or indirectly contains generally accepted signs of pornography that offends, infringes, damages someone’s dignity, contains calls for violence, atrocities and other actions that entail violations of applicable law, certain territorial jurisdictions, containing malicious software and / or other information that could be harmful to third parties.
              </p>
              <p> 2.9. In case of violation of the conditions of clause 2.8. of this Agreement and non-compliance with the requirements of the CPA network, including the removal of such information from public access, the Website Clients are liable under the provisions of this Agreement and (or) the current legislation of the Russian Federation. In this case, the CPA network has the right to remove the one mentioned in clause 2.8. information yourself.
              </p>
              <p> 2.10. The CPA network is not responsible for the results of visits by the Client to external (external) resources, links to which can be posted on the Site. Results are understood to mean any result, regardless of its nature, as well as the result of which the Client suffered any material losses, moral damage and other negative manifestations.
              </p>
              <p> 2.11. The procedure for conducting remote trade, the rights and obligations of the Parties to the agreement, as well as third parties, the special requirements for the processes of interaction between the Parties and the design of advertising platforms, are regulated in the normative procedure - the Federal Law "On Advertising", the Rules for conducting remote trade, approved by the Government of the Russian Federation Federation No. 612 of 09/27/2007, as well as other regulatory acts and this Agreement.
              </p>
              <p> <strong> 3. Advertiser Rights and Responsibilities </strong>
              </p>
              <p> 3.1. The advertiser is obliged to offer the Customer services for the delivery of goods by sending them by mail or transportation indicating the delivery method used and the type of transport.
              </p>
              <p> 3.2. The advertiser is obliged to inform the Client about the need to use qualified specialists for connecting, commissioning and putting into operation technically complex goods, which, according to technical requirements, cannot be put into operation without the participation of relevant specialists.
              </p>
              <p> 3.3. The advertiser is not entitled without the consent of the Client to perform additional work (provide services) for a fee.
              </p>
              <p> 3.4. The advertiser is obliged, prior to concluding the retail sale and purchase agreement (hereinafter referred to as the “Agreement”), to provide the Client with information about the main consumer properties of the goods and the address (location) of the Advertiser, about the place of manufacture of the goods, the full firm name (name) of the Advertiser, about the price and conditions purchase of goods, on their delivery, service life, shelf life and warranty period, on the procedure for payment for the goods, as well as on the period during which the proposal to conclude the Agreement is valid.
              </p>
              <p> 3.5. At the time of delivery of the goods, the Advertiser is obliged to inform the Client in writing of the following information (for imported goods - in Russian):
              </p>
              <p> 3.5.1. the name of the technical regulation or other designation established by the legislation of the Russian Federation on technical regulation and indicating the mandatory confirmation of conformity of the goods;
              </p>
              <p> 3.5.2. information on the basic consumer properties of the goods (works, services), and regarding food products - information on the composition (including the name of the food additives used in the manufacturing process of food additives, biologically active additives, information on the presence in the food products of components obtained using genetically modified organisms), nutritional value, purpose, on the conditions for the use and storage of food, on the methods of making ready-made dishes, weight (volume), date and place of manufacture and packaging (packaging) of food products, as well as information on contraindications for their use in certain diseases;
              </p>
              <p> 3.5.3. price in rubles and conditions for the acquisition of goods (work, services);
              </p>
              <p> 3.5.4. information about the warranty period, if installed;
              </p>
              <p> 3.5.5. terms and conditions for the efficient and safe use of goods;
              </p>
              <p> 3.5.6. information on the service life or expiration date of the goods, as well as information on the necessary actions of the Customer after the specified periods and possible consequences if such actions are not performed, if the goods after the specified periods endanger the life, health and property of the Customer or become unsuitable for the intended use ;
              </p>
              <p> 3.5.7. location (address), company name (name) of the manufacturer (Advertiser), location (address) of the organization (s) authorized by the manufacturer (Advertiser) to accept claims from the Client and performing repair and maintenance of the goods, for imported goods - name of the country origin of goods;
              </p>
              <p> (see text in previous edition)
              </p>
              <p> 3.5.8. information on the mandatory confirmation of the conformity of goods (services) to the mandatory requirements that ensure their safety for the life, health of the Client, the environment and the prevention of damage to the Client’s property in accordance with the legislation of the Russian Federation;
              </p>
              <p> 3.5.9. information on the rules for the sale of goods (work, services);
              </p>
              <p> 3.5.10. information about the specific person who will perform the work (provide the service), and information about him, if it matters based on the nature of the work (service);
              </p>
              <p> 3.5.11 information on the energy efficiency of goods, for which the requirement for such information is determined in accordance with the legislation of the Russian Federation on energy conservation and on increasing energy efficiency.
              </p>
              <p> 3.6. The Advertiser is obliged to provide information to the Client if the goods purchased by the Client were in use or in which the deficiency (s) were eliminated.
              </p>
              <p> 3.7. The advertiser is obliged to inform the Client about the product, including its operating conditions and storage rules, is communicated to the Client by placing it on the product, on electronic media attached to the product, in the product itself (on the electronic board inside the product in the menu section), on packaging, packaging, label, label, in technical documentation or in another way established by the legislation of the Russian Federation.
              </p>
              <p> 3.8. The Advertiser is obliged to inform the Client about the period during which the offer for the sale of goods / services on the Site is valid.
              </p>
              <p> 3.9. The advertiser has the right to accept or reject the Client’s offer to send goods by post to the “Poste restante” address.
              </p>
              <p> 3.10. The advertiser is required to ensure the confidentiality of personal data about the Client in accordance with the legislation of the Russian Federation in the field of personal data.
              </p>
              <p> 3.11. The Advertiser provides the Client with catalogs, booklets, prospectuses, photographs or other informational materials containing complete, reliable and accessible information characterizing the offered goods.
              </p>
              <p> 3.12. If the Customer rejects the goods, the Advertiser is obligated to return to him the amount paid by the Customer in accordance with the Agreement, with the exception of the costs of the Advertiser for the delivery of the returned goods from the Customer, no later than 10 days from the date the client submits the corresponding request.
              </p>
              <p> 3.13. If the Agreement is concluded with the condition of delivery of goods to the Client, the Advertiser is obliged to deliver the goods to the place specified by the Client within the time period established by the Agreement, and if the place of delivery of goods by the Client is not indicated, then to his place of residence.
              </p>
              <p> 3.14. The Advertiser is obliged to transfer the goods to the Client in the manner and terms established in the Agreement.
              </p>
              <p> 3.15. The Advertiser is obliged to transfer to the Customer goods whose quality corresponds to the Agreement and the information provided to the Customer upon conclusion of the Agreement, as well as information communicated to him when transferring the goods (in the technical documentation attached to the goods, on the labels, by marking or in other ways provided for for certain types of goods).
              </p>
              <p> 3.16. If the Advertiser, when concluding the Agreement, was notified by the Client about the specific purposes of purchasing the goods, the Advertiser is obliged to transfer to the Client goods suitable for use in accordance with these purposes.
              </p>
              <p> 3.17. The costs of the return of the amount paid by the Client in accordance with the Agreement shall be borne by the Advertiser.
              </p>
              <p> 3.18. Payment for goods by the Client by transferring funds to a third party account indicated by the Advertiser does not relieve the Advertiser of the obligation to refund the amount paid by the Client when the Client returns the goods of both appropriate and inadequate quality.
              </p>
              <p> 3.19. The advertiser, posting information on the site, both personally and entrusting it to third parties, including the Site Administrator, guarantees that he has the right to publish and use the materials posted, and is solely responsible for copyright infringements of third parties.
              </p>
              <p> <strong> 4. Customer Rights and Obligations </strong>
              </p>
              <p> 4.1. The client has the right to refuse the goods at any time before its transfer, and after the transfer of the goods - within 7 days.
              </p>
              <p> 4.2. The client has the right to refuse the goods within 3 months from the moment of transfer of the goods, if information on the procedure and terms for returning goods of good quality was not provided in writing at the time of delivery of the goods.
              </p>
              <p> 4.3. Return of goods of good quality is possible if its presentation, consumer properties, as well as a document confirming the fact and conditions of purchase of the specified goods are preserved . The absence of the specified document by the Client does not deprive him of the opportunity to refer to other evidence of the purchase of goods from this Advertiser.
              </p>
              <p> 4.4. The Client does not have the right to refuse the goods of good quality, having individually defined properties, if the specified goods can be used exclusively by the Client who purchases it.
              </p>
              <p> 4.5. The Client is obliged to re-pay the cost of goods delivery services, if the goods were delivered within the time period established by the Agreement, but the goods were not transferred to the Client through his fault, subsequent delivery is carried out in the new terms agreed with the Advertiser
              </p>
              <p> 4.6. If the goods are transferred to the Customer in violation of the terms of the Agreement regarding the quantity, assortment, quality, completeness, packaging and (or) packaging of goods, the Customer may notify the Advertiser of these violations no later than 20 days after receipt of the goods.
              </p>
              <p> 4.7. If defects in the goods are discovered for which no warranty or expiration dates have been established, the Client has the right to submit claims for defects in the goods within a reasonable time, but within 2 years from the date of transfer to the Client, if longer periods are not established by regulatory enactments or the Agreement.
              </p>
              <p> 4.8. The client has the right to submit claims to the Advertiser regarding defects in the goods if they are discovered during the warranty period or expiration date.
              </p>
              <p> 4.9. A customer who has sold goods of inadequate quality, if this has not been agreed by the Advertiser, has the right, at his option, to demand:
              </p>
              <p> a) gratuitous elimination of defects in the goods or reimbursement of expenses for their correction by the Client or a third party;
              </p>
              <p> b) a commensurate reduction in the purchase price;
              </p>
              <p> c) replacements for goods of a similar brand (model, article) or for the same goods of another brand (model, article) with the corresponding recalculation of the purchase price. At the same time, in relation to technically complex and expensive goods, these requirements of the Client are subject to satisfaction in the event of detection of significant deficiencies.
              </p>
              <p> 4.10. The client, instead of presenting the requirements specified in clause 4.9 of this Agreement, has the right to refuse to execute the Agreement and demand the return of the amount paid for the purchased goods. At the request of the Advertiser and at his expense, the Client must return the goods with defects.
              </p>
              <p> 4.11. The client has the right to demand full compensation for losses incurred as a result of the sale of goods of inadequate quality. Losses are reimbursed within the time limits established by the Law of the Russian Federation "On Protection of Consumer Rights" to satisfy the relevant requirements of the Client.
              </p>
              <p> 4.12. The Client has the right to refuse to execute the Agreement and demand compensation for losses caused if the Advertiser refuses to transfer the goods.
              </p>
              <p> 4.13. When returning goods of inadequate quality, the Client’s absence of a document confirming the fact and conditions of purchase of the goods does not deprive him of the opportunity to refer to other evidence of the purchase of goods from the Advertiser.
              </p>
              <p> 4.14. The refusal or evasion of the Advertiser from the preparation of the invoice or act does not deprive the Client of the right to demand the return of the goods and (or) the return of the amount paid by the Client in accordance with the Agreement.
              </p>
              <p> 4.15. The Client has the right to refuse to pay for additional works (services) that are not specified by the Agreement, and if they are paid, the Client has the right to demand from the Advertiser a refund of the amount paid in excess of the specified amount.
              </p>
              <p> 4.16. By analogy with the instructions set out in clause 4.16. of this Agreement, the Client agrees to act, in the case of using the results of intellectual property, that belong to third parties. The method and procedure for implementation is specified in the process of negotiations with the copyright holder of the materials.
              </p>
              <p> <strong> 5. Responsibility of the parties </strong>
              </p>
              <p> 5.1. CPA-network is not responsible for the actions of the Client, which entailed a violation of the rights of third parties, except as otherwise provided by applicable law of the Russian Federation.
              </p>
              <p> 5.2. The CPA network is not responsible for the content of information posted by the Advertiser and / or Client.
              </p>
              <p> 5.3. СРА-network is not responsible for the content of the feedback from the Clients of the Site. Customer reviews of the Site are the subjective opinions of their authors, in no way claiming to be objective. They may not coincide with public opinion and may not correspond to reality.
              </p>
              <p> 5.4. The decision on the issuance / non-issuance of personal data is taken by the CPA network only on the basis of a request sent by the person of the CPA network in the manner established by the norms of the current legislation.
              </p>
              <p> 5.5. CPA-network has the right not to respond to requests, appeals and letters that do not contain the details of the applicant (name, contact details).
              </p>
              <p> 5.6. CPA-network is not responsible for the registration data that were indicated by the Client in interaction with the information field of the Site.
              </p>
              <p> 5.7. The CPA network has the right, without giving reasons, to restrict, block the Client’s access (including unregistered) to the Site, with partial or complete deletion of information that was posted by the Client on the Site. The CPA network is obligated to consider the claim drawn up in accordance with Section 5 of the agreement within 30 (thirty) calendar days from the date of its receipt.
              </p>
              <p> <strong> 6. Dispute Resolution Procedure </strong>
              </p>
              <p> 6.1. In case of revealing on the Site of the posted information containing the results of intellectual property belonging to third parties, the copyright holder is obliged:
              </p>
              <p> 6.1.1. Make a claim indicating the factual and regulatory grounds that enable the CPA network to transfer information to a person who violates rights, or to remove information from public access.
              </p>
              <p> 6.1.2. Attach evidence of the originality of the result of intellectual property to the claim (original copy, other documents confirming ownership of the copyright object).
              </p>
              <p> 6.1.3. Send a package of documents referred to in the provisions of paragraphs. 6.1.1., 6.1.2. of this Agreement, to the email inbox. </a>
              </p>
              <p> <strong> 7. Other conditions </strong>
              </p>
              <p> 7.1. All possible situations, disputes arising from the relationship between the Client and the Advertiser, as well as the Client, the Advertiser and the CPA network, not regulated by this Agreement, are resolved in the manner determined by the norms of the current legislation of the Russian Federation.
              </p>
              <p> 7.2. The parties to this Agreement are aware of the scope of the rights and obligations generated by the relationships of the persons referred to in this Agreement, and fully report to their actions, fully understanding the legal nature of the consequences of such actions.
              </p>
              <p> 7.3. Inaction on the part of the CPA network in case of violation by any of the Clients of the provisions of the Agreement does not deprive the CPA network of the right to take later appropriate actions in defense of its interests and protection of rights protected by law.
              </p>
</body>
</html>