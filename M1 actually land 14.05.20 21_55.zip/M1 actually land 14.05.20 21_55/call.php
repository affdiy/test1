﻿<!DOCTYPE html>
<html>
<head>
    <title>Спецпредложение от нашего интернет-магазина, товары по супер цене! Скидки до 80%.</title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="/assets_pages/upsells/favicon.ico" type="image/x-icon">
    <link rel="shortcut icon" href="/assets_pages/upsells/favicon.ico" type="image/x-icon">
    <link href='//fonts.googleapis.com/css?family=Roboto:400,300,500,300italic,700&subset=latin,cyrillic'
          rel='stylesheet' type='text/css'>
    <link media="all" href="/assets_pages/upsells/css/main.css?v=0.1" rel="stylesheet" type="text/css"/>
    <link media="all" href="/assets_pages/upsells/css/hint.css" rel="stylesheet" type="text/css"/>
    <script src="//ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
    <script src="/assets_pages/upsells/js/jquery.placeholder.js"></script>

    <script type="text/javascript" src="/assets_pages/js/lib.js"></script>
    <script src="/assets_pages/upsells/js/init.js"></script>
</head>

<body class="man" style="background-color: #f1f4f6;">
<div class="first-block">
    <div class="wrapper">
        <div class="wrap">
            <div class="top-title top-title-c">
                <h2 style="color: #55d90d;">Спасибо. Ваш заказ принят!</h2>
                <div style="color: white; font-weight: bold;">Мы позвоним Вам в ближайшие 15 минут. Держите телефон рядом.<br />
                    Наш колл центр работает круглосуточно.</div>
            </div>
        </div>
    </div>
</div>

<div class="section footer">
    <div class="wrap clearfix">
        <div class="left clearfix foot-logo">
            <p><b>Интернет-магазин «TOP-Shop»</b><br/><span>Дарим покупателям радость с 2009 года.</span></p>
        </div>
        <div class="right"><p>Copyright (c) 2019<br/>ОГРН 34582345720962</p></div>
    </div>
</div>

<!--PopUp-->
<div class="popup reg_form reg_form_pop">
    <a class="close">Close</a>

    <h2 id="center1">Написать отзыв</h2>

    <div>
        <form id="comment-form" action="" class="clearfix">
            <div>
                <input type="text" placeholder="Введите ваше имя" required=""/>
            </div>
            <div>
                <textarea cols="" rows="8" placeholder="Введите текст отзыва" required=""></textarea>
            </div>
            <button type="submit">Отправить</button>
        </form>
    </div>
</div>
<script src="//hostline.today/assets_pages/js/m1ref.js"></script>
<script type="text/javascript">
    var m1_product_id = 9060;
    var ref = 836525;
    var script = document.createElement("script");
    script.src = "https://m1-shop.ru/send_order/?ref="+ref+"&s="+getC("s")+"&w="+getC("w")+"&t="+getC("t")+"&p="+getC("p")+"&m="+getC("m")+"&product_id="+m1_product_id+'&out=1';
    document.body.appendChild(script);
</script>







</body>
</html>

